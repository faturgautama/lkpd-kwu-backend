-- AlterTable
ALTER TABLE "kelompok_proyek" ADD COLUMN     "appresiasi" TEXT DEFAULT '';
