-- AlterTable
ALTER TABLE "kuis" ADD COLUMN     "sudah_penilaian" BOOLEAN DEFAULT false;
