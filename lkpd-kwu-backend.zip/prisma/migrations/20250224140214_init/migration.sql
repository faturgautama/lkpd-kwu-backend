/*
  Warnings:

  - You are about to drop the column `sudah_penilaian` on the `kuis` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "kuis" DROP COLUMN "sudah_penilaian";
