-- AlterTable
ALTER TABLE "jawaban_simulasi" ADD COLUMN     "type" TEXT DEFAULT 'lpt';
