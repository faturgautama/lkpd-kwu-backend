-- AlterTable
ALTER TABLE "kuis" ADD COLUMN     "type" TEXT DEFAULT 'essai';
