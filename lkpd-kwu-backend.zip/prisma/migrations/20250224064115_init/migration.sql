-- AlterTable
ALTER TABLE "jawaban_kuis" ALTER COLUMN "is_correct" DROP NOT NULL;
